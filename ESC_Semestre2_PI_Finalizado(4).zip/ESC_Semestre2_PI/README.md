Trabalho do segundo semestre
