import jwt from 'jsonwebtoken';

const auth = (req, res, next) => {
  // Obter o token do header
  const token = req.header('x-auth-token');

  // Checar se não há token
  if (!token) {
    return res.status(401).json({ msg: 'Nenhum token, autorização negada' });
  }

  try {
    // Verificar o token
    // O segredo do JWT deve ser uma variável de ambiente!
    const jwtSecret = process.env.JWT_SECRET || 'seu_segredo_jwt_aqui';
    const decoded = jwt.verify(token, jwtSecret);

    // Adicionar o usuário (participante) do payload
    req.participante = decoded.participante;
    next();
  } catch (err) {
    res.status(401).json({ msg: 'Token não é válido' });
  }
};

export default auth;
