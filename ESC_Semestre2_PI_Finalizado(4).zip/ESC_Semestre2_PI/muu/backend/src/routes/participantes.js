import express from 'express'
import auth from '../middleware/auth.js'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
const router = express.Router();

// GET - Listar todos os participantes
router.get('/', auth, async (req, res) => {
  try {
    const executeQuery = req.app.locals.executeQuery;
    const sql = `
      SELECT p.*, e.nome as edicao_nome 
      FROM participantes p 
      LEFT JOIN edicoes e ON p.edicao_id = e.id 
      ORDER BY p.created_at DESC
    `;
    
    const rows = await executeQuery(sql);
    
    res.json({
      message: 'Participantes listados com sucesso',
      data: rows
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET - Buscar participante por ID
router.get('/:id', auth, async (req, res) => {
  try {
    const executeQuery = req.app.locals.executeQuery;
    const sql = `
      SELECT p.*, e.nome as edicao_nome 
      FROM participantes p 
      LEFT JOIN edicoes e ON p.edicao_id = e.id 
      WHERE p.id = ?
    `;
    const params = [req.params.id];
    
    const rows = await executeQuery(sql, params);
    
    if (rows.length > 0) {
      res.json({
        message: 'Participante encontrado',
        data: rows[0]
      });
    } else {
      res.status(404).json({ error: 'Participante não encontrado' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET - Buscar participantes por edição
router.get('/edicao/:edicaoId', async (req, res) => {
  try {
    const executeQuery = req.app.locals.executeQuery;
    const sql = `
      SELECT p.*, e.nome as edicao_nome 
      FROM participantes p 
      LEFT JOIN edicoes e ON p.edicao_id = e.id 
      WHERE p.edicao_id = ?
      ORDER BY p.nome
    `;
    const params = [req.params.edicaoId];
    
    const rows = await executeQuery(sql, params);
    
    res.json({
      message: 'Participantes da edição listados com sucesso',
      data: rows
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST - Criar novo participante
router.post('/', async (req, res) => {
  try {
    const { nome, email, telefone, tipo, edicao_id, senha } = req.body;
    
    if (!nome || !email || !tipo || !senha) {
      return res.status(400).json({ error: 'Nome, email, tipo e senha são obrigatórios' });
    }

    // Criptografar a senha
    const salt = await bcrypt.genSalt(10);
    const senhaHash = await bcrypt.hash(senha, salt);

    const executeQuery = req.app.locals.executeQuery;
    const sql = 'INSERT INTO participantes (nome, email, telefone, tipo, edicao_id, senha) VALUES (?, ?, ?, ?, ?, ?)';
    const params = [nome, email, telefone, tipo, edicao_id, senhaHash];
    
    const result = await executeQuery(sql, params);
    
    res.status(201).json({
      message: 'Participante criado com sucesso',
      data: {
        id: result.insertId,
        nome,
        email,
        telefone,
        tipo,
        edicao_id
      }
    });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      res.status(400).json({ error: 'Email já cadastrado' });
    } else {
      res.status(500).json({ error: error.message });
    }
  }
});

// PUT - Atualizar participante
router.put('/:id', auth, async (req, res) => {
  try {
    const { nome, email, telefone, tipo, edicao_id, senha } = req.body;
    
    if (!nome || !email || !tipo) {
      return res.status(400).json({ error: 'Nome, email e tipo são obrigatórios' });
    }
    
    let sql = 'UPDATE participantes SET nome = ?, email = ?, telefone = ?, tipo = ?, edicao_id = ? WHERE id = ?';
    let params = [nome, email, telefone, tipo, edicao_id, req.params.id];

    if (senha) {
      const salt = await bcrypt.genSalt(10);
      const senhaHash = await bcrypt.hash(senha, salt);
      sql = 'UPDATE participantes SET nome = ?, email = ?, telefone = ?, tipo = ?, edicao_id = ?, senha = ? WHERE id = ?';
      params = [nome, email, telefone, tipo, edicao_id, senhaHash, req.params.id];
    }

    const executeQuery = req.app.locals.executeQuery;
    
    const result = await executeQuery(sql, params);
    
    if (result.affectedRows === 0) {
      res.status(404).json({ error: 'Participante não encontrado' });
    } else {
      res.json({
        message: 'Participante atualizado com sucesso',
        data: {
          id: req.params.id,
          nome,
          email,
          telefone,
          tipo,
          edicao_id
        }
      });
    }
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      res.status(400).json({ error: 'Email já cadastrado' });
    } else {
      res.status(500).json({ error: error.message });
    }
  }
});

// DELETE - Excluir participante
router.delete('/:id', auth, async (req, res) => {
  try {
    const executeQuery = req.app.locals.executeQuery;
    const sql = 'DELETE FROM participantes WHERE id = ?';
    const params = [req.params.id];
    
    const result = await executeQuery(sql, params);
    
    if (result.affectedRows === 0) {
      res.status(404).json({ error: 'Participante não encontrado' });
    } else {
      res.json({
        message: 'Participante excluído com sucesso',
        changes: result.affectedRows
      });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// module.exports = router;
// POST - Rota de Login
router.post('/login', async (req, res) => {
  try {
    const { email, senha } = req.body;

    if (!email || !senha) {
      return res.status(400).json({ error: 'Email e senha são obrigatórios' });
    }

    const executeQuery = req.app.locals.executeQuery;
    const sql = 'SELECT * FROM participantes WHERE email = ?';
    const params = [email];
    
    const rows = await executeQuery(sql, params);

    if (rows.length === 0) {
      return res.status(401).json({ error: 'Credenciais inválidas' });
    }

    const participante = rows[0];

    // Verificar a senha
    const isMatch = await bcrypt.compare(senha, participante.senha);

    if (!isMatch) {
      return res.status(401).json({ error: 'Credenciais inválidas' });
    }

    // Gerar o token JWT
    const payload = {
      participante: {
        id: participante.id,
        tipo: participante.tipo,
        email: participante.email
      }
    };

    // O segredo do JWT deve ser uma variável de ambiente!
    // Por enquanto, vou usar um valor fixo, mas devo alertar o usuário.
    const jwtSecret = process.env.JWT_SECRET || 'seu_segredo_jwt_aqui';

    jwt.sign(
      payload,
      jwtSecret,
      { expiresIn: '1h' }, // Token expira em 1 hora
      (err, token) => {
        if (err) throw err;
        res.json({ 
          message: 'Login realizado com sucesso',
          token,
          participante: {
            id: participante.id,
            nome: participante.nome,
            email: participante.email,
            tipo: participante.tipo
          }
        });
      }
    );

  } catch (error) {
    console.error(error.message);
    res.status(500).json({ error: 'Erro no servidor' });
  }
});

export default router
