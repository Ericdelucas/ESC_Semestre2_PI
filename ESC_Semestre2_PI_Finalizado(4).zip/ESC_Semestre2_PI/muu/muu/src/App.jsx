import { useState, useEffect } from 'react'
import { Routes, Route, useNavigate } from 'react-router-dom'
import Header from './components/Header'
import LoginModal from './components/LoginModal'
import Welcome from './components/Welcome'
import Dashboard from './components/Dashboard'
import Edicoes from './components/Edicoes'
import Participantes from './components/Participantes'
import Equipes from './components/Equipes'
import Atividades from './components/Atividades'
import Relatorios from './components/Relatorios'
import Monitoramento from './components/Monitoramento'
import Doacoes from './components/Doacoes'
import Metas from './components/Metas'
import { AuthProvider, useAuth } from './contexts/AuthContext'
import PrivateRoute from './components/PrivateRoute' // Criaremos este componente em seguida
import api from './services/api' // Usaremos a API para buscar dados


function AppContent() {
  const { user } = useAuth();
  const [showLoginModal, setShowLoginModal] = useState(false);
  
  // Estados para dados do sistema (podem ser movidos para um Context ou custom hook)
  const [edicoes, setEdicoes] = useState([])
  const [participantes, setParticipantes] = useState([])
  const [equipes, setEquipes] = useState([])
  const [atividades, setAtividades] = useState([])
  const [metas, setMetas] = useState([])
  const [doacoes, setDoacoes] = useState([])

  // Função para buscar dados iniciais ou manter o estado
  const fetchData = async () => {
    // Implementar a busca de dados aqui, se necessário
    // Exemplo:
    // try {
    //   const edicoesRes = await api.get('/edicoes');
    //   setEdicoes(edicoesRes.data.data);
    // } catch (error) {
    //   console.error('Erro ao buscar edições:', error);
    // }
  };

  useEffect(() => {
    if (user) {
      fetchData();
    }
  }, [user]);

  return (
    <div className="App">
      <Header 
        // A navegação e o estado de login/logout agora são gerenciados internamente pelo Header
      />
      
      <main className="main">
        <Routes>
          <Route path="/" element={<Welcome onLogin={() => setShowLoginModal(true)} />} />
          
          {/* Rotas Protegidas */}
          <Route path="/dashboard" element={<PrivateRoute element={<Dashboard edicoes={edicoes} participantes={participantes} equipes={equipes} atividades={atividades} />} />} />
          <Route path="/edicoes" element={<PrivateRoute element={<Edicoes edicoes={edicoes} onEdicoesChange={setEdicoes} />} />} />
          <Route path="/participantes" element={<PrivateRoute element={<Participantes participantes={participantes} setParticipantes={setParticipantes} />} />} />
          <Route path="/equipes" element={<PrivateRoute element={<Equipes equipes={equipes} setEquipes={setEquipes} participantes={participantes} edicoes={edicoes} />} />} />
          <Route path="/atividades" element={<PrivateRoute element={<Atividades atividades={atividades} setAtividades={setAtividades} equipes={equipes} />} />} />
          <Route path="/relatorios" element={<PrivateRoute element={<Relatorios edicoes={edicoes} participantes={participantes} equipes={equipes} atividades={atividades} metas={metas} doacoes={doacoes} />} />} />
          <Route path="/monitoramento" element={<PrivateRoute element={<Monitoramento edicoes={edicoes} participantes={participantes} equipes={equipes} atividades={atividades} metas={metas} doacoes={doacoes} />} />} />
          <Route path="/doacoes" element={<PrivateRoute element={<Doacoes participantes={participantes} equipes={equipes} doacoes={doacoes} onDoacoesChange={setDoacoes} />} />} />
          <Route path="/metas" element={<PrivateRoute element={<Metas user={user} metas={metas} onMetasChange={setMetas} />} />} />
          
          {/* Rota 404 - Opcional */}
          <Route path="*" element={<h1 style={{padding: '20px', textAlign: 'center'}}>404 - Página Não Encontrada</h1>} />
        </Routes>
      </main>

      <LoginModal 
        show={showLoginModal}
        onClose={() => setShowLoginModal(false)}
      />
    </div>
  )
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App
