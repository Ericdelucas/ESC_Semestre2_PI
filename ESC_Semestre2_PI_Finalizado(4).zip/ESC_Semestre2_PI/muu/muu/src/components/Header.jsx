import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

function Header() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const navItems = [
    { name: 'Dashboard', path: '/dashboard' },
    { name: 'Edições', path: '/edicoes' },
    { name: 'Participantes', path: '/participantes' },
    { name: 'Equipes', path: '/equipes' },
    { name: 'Atividades', path: '/atividades' },
    { name: 'Relatórios', path: '/relatorios' },
    { name: 'Monitoramento', path: '/monitoramento' },
    { name: 'Doações', path: '/doacoes' },
    { name: 'Metas', path: '/metas' },
  ];

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const currentPath = window.location.pathname;

  return (
    <header className="header">
      <div className="container">
        <div className="logo">
          <i className="fas fa-heart"></i>
          <Link to="/"><span>Lideranças Empáticas</span></Link>
        </div>
        
        <nav className="nav">
          <ul id="navMenu">
            {user && navItems.map(item => (
              <li key={item.path}>
                <Link 
                  to={item.path}
                  className={currentPath === item.path ? 'active' : ''}
                >
                  {item.name}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        
        <div className="user-actions">
          {user ? (
            <>
              <span className="user-info">
                Olá, {user.nome} ({user.tipo})
              </span>
              <button className="btn btn-outline" onClick={handleLogout}>
                Sair
              </button>
            </>
          ) : (
            <Link to="/login">
              <button className="btn btn-outline">
                Login
              </button>
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}

export default Header;

